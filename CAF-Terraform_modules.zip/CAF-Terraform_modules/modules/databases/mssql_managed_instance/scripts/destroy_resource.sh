#!/bin/bash

echo "Script called"