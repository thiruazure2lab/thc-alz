# AVS IaC

## Introduction

## Terraform

## Build
### Pre-requisite

1. Install Terrform 
2. Install Azure CLI 
3. In CMD / Powershell / Git Bash  run the following before perform terraform plan
````
az login --use-device-code
az account set --subscription "<subscription ID>"
````

### Run Steps

1. Initialize Terraform

* Option 1: Preferred - without upgrade
````
terraform init
````
* Option 2: With version upgrade if you migrate to latest version
````
terraform init -upgrade
````

2. Create a terraform execution plan

````
terraform plan -out main.tfplan -var-file="../../../config/global.tfvars" -var-file="../../../config/south/dev.tfvars"
````

