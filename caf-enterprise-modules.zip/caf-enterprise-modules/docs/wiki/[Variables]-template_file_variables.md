## Overview

[**template_file_variables**](#overview) `map(any)` (optional)

If specified, provides the ability to define custom template variables used when reading in template files from the built-in and custom library_path.

## Default value

`{}`

## Validation

None

## Usage

_coming soon_

[//]: # "************************"
[//]: # "INSERT LINK LABELS BELOW"
[//]: # "************************"
[this_page]: # "Link for the current page."
