#cloud-config
package_upgrade: true
packages:
  - nginx